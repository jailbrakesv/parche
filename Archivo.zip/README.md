# All-in-One RootlessJB Patching Tool For Tweaks

### Usage

Run `chmod +x ./patcherplus`.

Run `./patcherplus`.

Profit :)
